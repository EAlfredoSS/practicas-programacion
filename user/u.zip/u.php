<?php
// ==================== INICIO - CONSOLIDACIÓN DE PHP ====================
session_start();

require('../files/bd.php');
require('../files/idiomasnivel.php');
require('../templates/header_simplified.html');

$identificador_usu_buscado = $_GET['identificador'];
$identificador2017 = $_SESSION['orden2017'];
$_SESSION['idusuario2019'] = $identificador2017;

// FUNCIÓN PARA DETECTAR FOTOS (optimizada)
function detectarFoto($base_path, $tipo = 'foto')
{
    $extensiones = ['jpg', 'png', 'gif', 'bmp'];
    foreach ($extensiones as $ext) {
        $ruta = "../uploader/upload_pic/" . ($tipo == 'thumb' ? 'thumb_' : '') . $base_path . "." . $ext;
        if (file_exists($ruta)) {
            return $ruta;
        }
    }
    return "../uploader/default.jpg";
}

// FUNCIÓN DE RENDERIZADO DE PUNTOS DE NIVEL
function renderLevelDots($level)
{
    $level = min(7, max(1, intval($level)));
    $colors = [
        1 => '#ff6b6b',
        2 => '#ff9f4b',
        3 => '#ffd966',
        4 => '#a9d96c',
        5 => '#6bb86b',
        6 => '#4a9eff',
        7 => '#2b4f8c'
    ];

    $html = '<div class="level-dots">';
    for ($i = 1; $i <= 7; $i++) {
        $color = ($i <= $level) ? $colors[$level] : '#e0e0e0';
        $html .= "<span style=\"background-color: {$color};\"></span>";
    }
    $html .= '</div>';
    return $html;
}

// FUNCIÓN PARA OBTENER DISPLAY DE EVALUACIONES
function getEvaluationDisplay($num_evalu, $nota_evalu)
{
    if ($num_evalu == 0) {
        return ['has_evaluations' => false, 'percentage' => 0, 'total' => 0, 'display' => 'No evaluations yet'];
    }

    $percentage = ($nota_evalu > 1) ? round($nota_evalu) : round($nota_evalu * 100);
    $percentage = min(100, $percentage);

    return [
        'has_evaluations' => true,
        'percentage' => $percentage,
        'total' => $num_evalu,
        'display' => $percentage . '% positive'
    ];
}

// QUERY USUARIO ACTUAL
$query234 = "SELECT * FROM mentor2009 WHERE orden='" . $identificador2017 . "'";
$result234 = mysqli_query($link, $query234);
if (!mysqli_num_rows($result234))
    die("User unregistered. <a href=\"http://www.lingua2.com\">Information</a>");
$fila234 = mysqli_fetch_array($result234);

$mi_gpslat = $fila234['Gpslat'];
$mi_gpslng = $fila234['Gpslng'];
$mi_email = $fila234['Email'];

// QUERY USUARIO BUSCADO
$query = "SELECT * FROM mentor2009 WHERE orden='" . $identificador_usu_buscado . "'";
$result = mysqli_query($link, $query);
if (!mysqli_num_rows($result))
    die("User unregistered. <a href=\"http://www.lingua2.com\">Information</a>");
$fila = mysqli_fetch_array($result);

$ciudad1 = $fila['Ciudad'];
$id_del_receptor = $fila['orden'];
$gpslat11 = $fila['Gpslat'];
$gpslng11 = $fila['Gpslng'];
$email_del_usu = $fila['Email'];
$email_verified = $fila['Emailverif'];
$availability100 = $fila['Disponibilidadcomentarios'];
$othercomments100 = $fila['Otroscomentarios'];
$foto_nombre = detectarFoto($fila['orden'], 'foto');
$thumb_nombre = detectarFoto($fila['orden'], 'thumb');
$fb_ident = $fila['fbid'];

// PROCESAMIENTO NOMBRE
$nombre_usuar = $fila["nombre"];
$arr = explode(' ', trim($nombre_usuar));
$nombre_usuar = ucfirst(substr($arr[0], 0, 13));

// CÁLCULO DE DISTANCIA
$query333 = "
    SELECT (acos(sin(radians($mi_gpslat)) * sin(radians($gpslat11)) + 
    cos(radians($mi_gpslat)) * cos(radians($gpslat11)) * 
    cos(radians($mi_gpslng) - radians($gpslng11))) * 6378) 
    AS distanciaPunto1Punto2
";
$result333 = mysqli_query($link, $query333);
$fila333 = mysqli_fetch_array($result333);
$distancia_entre_partners = round($fila333['distanciaPunto1Punto2'], 2);

// OBTENER EVALUACIONES DEL USUARIO
$num_evaluations = (int)$fila['ev_num_diaria'];
$nota_evalu = $fila['ev_proporc_diaria'];
$evaluation_data = getEvaluationDisplay($num_evaluations, $nota_evalu);

// ==================== PROCESAMIENTO DE IDIOMAS (MY_LANGS) ====================
$query_my_langs = "
    SELECT my_l.*, l_names.Print_Name AS full_lang_name, l.lang_id AS lang_codigo2letras
    FROM my_langs my_l
    LEFT JOIN languages_names l_names ON my_l.lang_id=l_names.Id
    LEFT JOIN languages1 l ON my_l.lang_id=l.Id
    WHERE my_l.id='$identificador_usu_buscado' 
    ORDER BY my_l.level_id DESC";
$result_my_langs = mysqli_query($link, $query_my_langs);
$num_my_langs = mysqli_num_rows($result_my_langs);

$my_langs_array = $my_langs_2letters_array = $my_langs_full_name_array = $my_langs_level_array = array();
$my_langs_forshare_array = $my_langs_price_array = $my_langs_typeofexchange_array = array();
$my_langs_priceorexchangetext_array = $my_langs_level_image_array = array();

for ($jjj = 0; $jjj < $num_my_langs; $jjj++) {
    $fila_my_langs = mysqli_fetch_array($result_my_langs);
    array_push($my_langs_full_name_array, $fila_my_langs['full_lang_name']);
    array_push($my_langs_array, $fila_my_langs['lang_id']);
    array_push($my_langs_2letters_array, $fila_my_langs['lang_codigo2letras']);
    array_push($my_langs_level_array, $fila_my_langs['level_id']);
    array_push($my_langs_forshare_array, $fila_my_langs['for_share']);
    array_push($my_langs_price_array, $fila_my_langs['lang_price']);
}

// PROCESAMIENTO DE DUPLICADOS MY_LANGS
$duplicate_langs = array_count_values($my_langs_array);
$lista_idiomas_dup = array_keys(array_diff($duplicate_langs, [1]));
$n_dups = count($lista_idiomas_dup);

for ($iiii = 0; $iiii < $n_dups; $iiii++) {
    $lang2 = $lista_idiomas_dup[$iiii];
    $cnt = $duplicate_langs[$lang2];
    $keys = array_keys($my_langs_array, $lang2);

    $nombres_combinados = array();
    foreach ($keys as $k) {
        $nombres_combinados[] = $my_langs_full_name_array[$k];
    }

    for ($j = 0; $j < $cnt; $j++) {
        $key2 = $keys[$j];
        if ($j < $cnt - 1) {
            $my_langs_array[$key2] = '_delete_';
        } else {
            $my_langs_full_name_array[$key2] = implode(' | ', $nombres_combinados);
        }
    }
}

// ASIGNACIÓN DE IMÁGENES DE NIVEL Y TIPO DE INTERCAMBIO
$niveles_map = [
    0 => 'no_data.png',
    1 => 'zero_knowledge.png',
    2 => 'a1.png',
    3 => 'a2.png',
    4 => 'b1.png',
    5 => 'b2.png',
    6 => 'c1.png',
    7 => 'c2.png'
];

for ($iii = 0; $iii < count($my_langs_level_array); $iii++) {
    $my_langs_level_image_array[$iii] = $niveles_map[$my_langs_level_array[$iii]] ?? 'no_data.png';

    if ($my_langs_forshare_array[$iii] == 0) {
        $my_langs_typeofexchange_array[$iii] = 'I know this language, but I do not want to exchange or teach it.';
        $my_langs_priceorexchangetext_array[$iii] = '';
    } else if ($my_langs_price_array[$iii] == null) {
        $my_langs_typeofexchange_array[$iii] = 'I know this language and I want to exchange it for another user\'s language (exchange free of cost).';
        $my_langs_priceorexchangetext_array[$iii] = "EXCH.";
    } else {
        $my_langs_typeofexchange_array[$iii] = "I know this language and I want to teach it for money.";
        $my_langs_priceorexchangetext_array[$iii] = "$my_langs_price_array[$iii] &#8364;/h";
    }
}

// LIMPIEZA DE MARCADORES '_delete_' Y REORGANIZACIÓN
$indices_validos = array_keys(array_diff($my_langs_array, ['_delete_']));
$my_langs_array = array_values(array_intersect_key($my_langs_array, array_flip($indices_validos)));
$my_langs_full_name_array = array_values(array_intersect_key($my_langs_full_name_array, array_flip($indices_validos)));
$my_langs_level_array = array_values(array_intersect_key($my_langs_level_array, array_flip($indices_validos)));
$my_langs_forshare_array = array_values(array_intersect_key($my_langs_forshare_array, array_flip($indices_validos)));
$my_langs_price_array = array_values(array_intersect_key($my_langs_price_array, array_flip($indices_validos)));
$my_langs_typeofexchange_array = array_values(array_intersect_key($my_langs_typeofexchange_array, array_flip($indices_validos)));
$my_langs_priceorexchangetext_array = array_values(array_intersect_key($my_langs_priceorexchangetext_array, array_flip($indices_validos)));
$my_langs_level_image_array = array_values(array_intersect_key($my_langs_level_image_array, array_flip($indices_validos)));
$my_langs_2letters_array = array_values(array_intersect_key($my_langs_2letters_array, array_flip($indices_validos)));

// ==================== PROCESAMIENTO DE IDIOMAS (LEARN_LANGS) ====================
$query_learn_langs = "
    SELECT learn_l.*, l_names.Print_Name AS full_lang_name, l.lang_id AS lang_codigo2letras
    FROM learn_langs learn_l
    LEFT JOIN languages_names l_names ON learn_l.lang_id=l_names.Id
    LEFT JOIN languages1 l ON learn_l.lang_id=l.Id
    WHERE learn_l.id='$identificador_usu_buscado' 
    ORDER BY learn_l.level_id DESC";
$result_learn_langs = mysqli_query($link, $query_learn_langs);
$num_learn_langs = mysqli_num_rows($result_learn_langs);

$learn_langs_array = $learn_langs_2letters_array = $learn_langs_full_name_array = $learn_langs_level_array = array();
$learn_langs_forshare_array = $learn_langs_price_array = $learn_langs_typeofexchange_array = array();
$learn_langs_priceorexchangetext_array = $learn_langs_level_image_array = array();

for ($jjj = 0; $jjj < $num_learn_langs; $jjj++) {
    $fila_learn_langs = mysqli_fetch_array($result_learn_langs);
    array_push($learn_langs_full_name_array, $fila_learn_langs['full_lang_name']);
    array_push($learn_langs_array, $fila_learn_langs['lang_id']);
    array_push($learn_langs_2letters_array, $fila_learn_langs['lang_codigo2letras']);
    array_push($learn_langs_level_array, $fila_learn_langs['level_id']);
    array_push($learn_langs_forshare_array, $fila_learn_langs['for_share']);
    array_push($learn_langs_price_array, $fila_learn_langs['lang_price']);
}

// PROCESAMIENTO DE DUPLICADOS LEARN_LANGS
$duplicate_langs = array_count_values($learn_langs_array);
$lista_idiomas_dup = array_keys(array_diff($duplicate_langs, [1]));
$n_dups = count($lista_idiomas_dup);

for ($iiii = 0; $iiii < $n_dups; $iiii++) {
    $lang2 = $lista_idiomas_dup[$iiii];
    $cnt = $duplicate_langs[$lang2];
    $keys = array_keys($learn_langs_array, $lang2);

    $nombres_combinados = array();
    foreach ($keys as $k) {
        $nombres_combinados[] = $learn_langs_full_name_array[$k];
    }

    for ($j = 0; $j < $cnt; $j++) {
        $key2 = $keys[$j];
        if ($j < $cnt - 1) {
            $learn_langs_array[$key2] = '_delete_';
        } else {
            $learn_langs_full_name_array[$key2] = implode(' | ', $nombres_combinados);
        }
    }
}

// ASIGNACIÓN DE IMÁGENES DE NIVEL LEARN_LANGS
for ($iii = 0; $iii < count($learn_langs_level_array); $iii++) {
    $learn_langs_level_image_array[$iii] = $niveles_map[$learn_langs_level_array[$iii]] ?? 'no_data.png';
}

// LIMPIEZA DE MARCADORES '_delete_' LEARN_LANGS
$indices_validos = array_keys(array_diff($learn_langs_array, ['_delete_']));
$learn_langs_array = array_values(array_intersect_key($learn_langs_array, array_flip($indices_validos)));
$learn_langs_full_name_array = array_values(array_intersect_key($learn_langs_full_name_array, array_flip($indices_validos)));
$learn_langs_level_array = array_values(array_intersect_key($learn_langs_level_array, array_flip($indices_validos)));
$learn_langs_forshare_array = array_values(array_intersect_key($learn_langs_forshare_array, array_flip($indices_validos)));
$learn_langs_price_array = array_values(array_intersect_key($learn_langs_price_array, array_flip($indices_validos)));
$learn_langs_typeofexchange_array = array_values(array_intersect_key($learn_langs_typeofexchange_array, array_flip($indices_validos)));
$learn_langs_priceorexchangetext_array = array_values(array_intersect_key($learn_langs_priceorexchangetext_array, array_flip($indices_validos)));
$learn_langs_level_image_array = array_values(array_intersect_key($learn_langs_level_image_array, array_flip($indices_validos)));
$learn_langs_2letters_array = array_values(array_intersect_key($learn_langs_2letters_array, array_flip($indices_validos)));

// DATOS ADICIONALES DEL USUARIO
$query77 = "SELECT * FROM mentor2009 WHERE orden='$identificador_usu_buscado'";
$result77 = mysqli_query($link, $query77);
if (!mysqli_num_rows($result77)) die("User unregistered 1.");
$fila77 = mysqli_fetch_array($result77);
$latitud1 = $fila77['Gpslat'];
$longitud1 = $fila77['Gpslng'];
$is_teacher = $fila77['Pais'];
?>

<style type="text/css">
    header {
        height: 55px;
    }

    body {
        background-color: #eeeeee !important;
    }

    /* ===== EXCEPCIÓN PARA EL ICONO DE HOME EN EL HEADER ===== */
    header .fa-home,
    header .fas.fa-home {
        color: #ffffff !important; /* Blanco */
    }

    /* MEJORAS DE DISEÑO - MANTENIENDO ESTRUCTURA */
    .user-data,
    .post-bar,
    .suggestions,
    .widget,
    .evaluation-widget {
        border-radius: 12px !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08) !important;
        transition: all 0.2s ease;
        border-left: 5px solid #e65f00;
        background: white;
    }

    /* ===== FOTO DE PERFIL REDONDA Y MÁS GRANDE ===== */
    .username-dt {
        display: flex;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, #e65f00, #c04e00) !important;
        padding: 25px 0 !important;
        border-radius: 12px 12px 0 0 !important;
        min-height: auto !important;
    }

    .usr-pic {
        width: 150px !important;
        height: 150px !important;
        border-radius: 50% !important;
        overflow: hidden !important;
        border: 4px solid white !important;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2) !important;
        margin: 0 auto !important;
    }

    .usr-pic img {
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
        border-radius: 50% !important;
    }

    /* Ajustar el contenedor para la foto */
    .user-profile .username-dt {
        min-height: auto !important;
        padding: 30px 0 !important;
    }

    /* ===== SIDEBAR IZQUIERDO - ALINEACIÓN PERFECTA ===== */
    .user-specs {
        padding-top: 8px !important;
        padding-right: 12px !important;
        padding-bottom: 8px !important;
        padding-left: 12px !important;
    }

    .user-specs h3 {
        margin-bottom: 5px;
        text-align: center;
    }

    .user-specs span {
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 6px;
        margin-bottom: 10px;
        font-size: 14px;
    }

    .user-specs h6 {
        display: flex;
        align-items: center;
        gap: 6px;
        margin: 8px 0;
        font-weight: 500;
    }

    .user-specs h6 i {
        width: 18px;
        text-align: center;
        color: #e65f00 !important;
    }

    .user-specs p {
        display: flex;
        align-items: center;
        gap: 6px;
        margin: 10px 0;
    }

    /* ===== ESTILO DE BOTONES COMO "DETAILS" ===== */
    .btn {
        border: 2px solid #e67e22 !important;
        background: linear-gradient(135deg, #fdf2e9, #fce8d6) !important;
        padding: 10px 18px !important;
        border-radius: 6px !important;
        cursor: pointer !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        display: flex !important;
        align-items: center !important;
        gap: 6px !important;
        color: #d35400 !important;
        text-transform: uppercase !important;
        width: 80% !important;
        justify-content: center !important;
        text-decoration: none !important;
        transition: all 0.2s ease !important;
        box-shadow: none !important;
        letter-spacing: normal !important;
        margin: 0 auto !important;
    }

    .btn:hover {
        background: linear-gradient(135deg, #e67e22, #d35400) !important;
        color: white !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 4px 8px rgba(230, 95, 0, 0.2) !important;
        border-color: #d35400 !important;
    }

    .btn:active {
        transform: translateY(0) !important;
        box-shadow: none !important;
    }

    .btn i {
        color: #d35400 !important;
        transition: color 0.2s ease !important;
    }

    .btn:hover i {
        color: white !important;
    }

    /* Botón Add to bookmarks - versión gris */
    .btn.launch-modal[data-url*="addbookmark"] {
        border: 2px solid #95a5a6 !important;
        background: linear-gradient(135deg, #f5f5f5, #e8e8e8) !important;
        color: #7f8c8d !important;
    }

    .btn.launch-modal[data-url*="addbookmark"] i {
        color: #7f8c8d !important;
    }

    .btn.launch-modal[data-url*="addbookmark"]:hover {
        background: linear-gradient(135deg, #95a5a6, #7f8c8d) !important;
        color: white !important;
        border-color: #7f8c8d !important;
    }

    .btn.launch-modal[data-url*="addbookmark"]:hover i {
        color: white !important;
    }

    /* Botón Write a message - naranja */
    .btn.launch-modal[data-target="#myModal"] {
        border: 2px solid #e67e22 !important;
        background: linear-gradient(135deg, #fdf2e9, #fce8d6) !important;
        color: #d35400 !important;
    }

    .btn.launch-modal[data-target="#myModal"] i {
        color: #d35400 !important;
    }

    .btn.launch-modal[data-target="#myModal"]:hover {
        background: linear-gradient(135deg, #e67e22, #d35400) !important;
        color: white !important;
    }

    .btn.launch-modal[data-target="#myModal"]:hover i {
        color: white !important;
    }

    /* Botón Request a meeting - VERDE (CORREGIDO) */
    .btn[style*="background-color: #2e8b57"] {
        border: 2px solid #27ae60 !important;
        background: linear-gradient(135deg, #e8f5e9, #c8e6c9) !important;
        color: #27ae60 !important;
    }

    .btn[style*="background-color: #2e8b57"] i {
        color: #27ae60 !important;
    }

    .btn[style*="background-color: #2e8b57"]:hover {
        background: linear-gradient(135deg, #27ae60, #2e8b57) !important;
        color: white !important;
        border-color: #2e8b57 !important;
    }

    .btn[style*="background-color: #2e8b57"]:hover i {
        color: white !important;
    }

    /* ===== UNIFICACIÓN DE ICONOS - NARANJA SÓLIDO ===== */
    .fas,
    .far,
    .fal,
    .fab,
    .fa {
        color: #e65f00 !important;
        opacity: 1 !important;
        font-weight: 900 !important;
    }

    /* Los iconos de información dentro de tooltips más simples */
    .tooltip-container .fas.fa-info-circle {
        color: #e65f00 !important;
        font-size: 12px !important;
        opacity: 0.7 !important;
        transition: opacity 0.2s;
    }

    .tooltip-container:hover .fas.fa-info-circle {
        opacity: 1 !important;
    }

    /* Estilo específico para iconos en títulos de widgets */
    .suggestions .sd-title h3 i {
        margin-right: 10px !important;
        color: #e65f00 !important;
        font-size: 16px;
    }

    /* Iconos en títulos de secciones principales */
    .job_descp h3 .fas {
        color: #e65f00 !important;
        margin-right: 8px;
    }

    .tooltip-container {
        position: relative;
        display: inline-block;
        margin-top: 6px !important;
    }

    .tooltip-text {
        font-size: 10px;
        visibility: hidden;
        width: 120px;
        background-color: #000;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 5px;
        position: absolute;
        z-index: 1;
        top: 125%;
        left: 50%;
        transform: translateX(-50%);
        opacity: 0;
        transition: opacity 0.3s;
        pointer-events: none;
    }

    .tooltip-container:hover .tooltip-text {
        visibility: visible;
        opacity: 0.75;
    }

    .form-control:focus {
        outline: none !important;
        border: 1px solid #e65f00 !important;
        box-shadow: 0 1px 8px #e65f00 !important;
    }

    .launch-modal:focus {
        box-shadow: 0 1px 8px #e65f00 !important;
    }

    .modal-body {
        position: relative;
        display: inline-block;
    }

    #charCount {
        position: absolute;
        bottom: 20px;
        right: 40px;
        color: #aaa;
        font-size: 12px;
        margin: 0;
    }

    /* ===== ESTILO DE TARJETAS DE IDIOMAS - 4 COLUMNAS ===== */
    .posts-section,
    .job_descp {
        width: 100% !important;
    }

    .skill-tags {
        list-style: none !important;
        padding: 0 !important;
        margin: 0 !important;
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 16px !important;
    }

    .skill-tags li {
        background: #ffffff !important;
        border: none !important;
        border-radius: 12px !important;
        padding: 16px 8px !important;
        text-align: center !important;
        transition: all 0.2s ease !important;
        width: calc(25% - 12px) !important; /* 4 columnas en desktop */
        min-width: 0 !important;
        max-width: none !important;
        box-sizing: border-box !important;
        list-style: none !important;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05) !important;
        margin: 0 !important;

        /* Flexbox para alineación vertical */
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important;
    }

    .skill-tags li:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08) !important;
    }

    .skill-tags li img {
        width: 50px !important;
        height: 35px !important;
        object-fit: cover !important;
        border-radius: 6px !important;
        margin-bottom: 10px !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
    }

    /* Estilos específicos para los puntos - CENTRADOS */
    .level-dots {
        display: flex !important;
        gap: 3px !important;
        justify-content: center !important;
        margin: 0 0 8px 0 !important;
        width: 100% !important;
    }

    .level-dots span {
        width: 8px !important;
        height: 8px !important;
        border-radius: 50% !important;
        display: inline-block !important;
    }

    /* Ajustes de texto - BIEN JERARQUIZADOS */
    .skill-tags li div {
        width: 100%;
    }
    
    .skill-tags li strong {
        font-size: 15px !important;
        font-weight: 700 !important;
        color: #2c3e50 !important;
        display: block;
        margin-bottom: 2px;
    }

    .skill-tags li span {
        font-size: 12px !important;
        color: #7f8c8d !important;
        line-height: 1.3 !important;
    }

    .skill-tags li .lang-price,
    .skill-tags li .lang-exchange {
        font-size: 12px !important;
        margin-top: 4px !important;
        padding: 2px 0 !important;
    }

    .lang-price {
        color: #e65f00 !important;
        font-weight: 600 !important;
    }

    .lang-exchange {
        color: #2e8b57 !important;
        font-weight: 600 !important;
    }

    /* Media queries para responsividad - CORREGIDAS */
    /* Pantallas medianas: 3 columnas */
    @media screen and (max-width: 1100px) {
        .skill-tags li {
            width: calc(33.333% - 11px) !important;
        }
    }

    /* Tablets: 2 columnas */
    @media screen and (max-width: 768px) {
        .skill-tags li {
            width: calc(50% - 8px) !important;
        }
    }

    /* Móviles: 1 columna */
    @media screen and (max-width: 480px) {
        .skill-tags li {
            width: 100% !important;
        }
    }

    /* WIDGET DE EVALUACIONES */
    .evaluation-widget {
        background-color: #ffffff;
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 25px;
        margin-top: 20px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
        border: 1px solid #cfb4a0;
        clear: both;
        width: 100%;
    }

    .evaluation-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 15px;
    }

    .evaluation-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
    }

    .evaluation-header a {
        color: #e65f00;
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
    }

    .evaluation-header a:hover {
        text-decoration: underline;
    }

    .evaluation-compact {
        text-align: center;
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .evaluation-compact .metric {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }

    .evaluation-compact .metric i {
        font-size: 24px;
        color: #e67e22;
    }

    .evaluation-compact .metric .percentage {
        font-size: 32px;
        font-weight: 700;
        color: #d35400;
        line-height: 1;
    }

    .evaluation-compact .metric .percentage small {
        font-size: 18px;
        font-weight: 400;
        color: #7f8c8d;
        margin-left: 2px;
    }

    .evaluation-compact .bar {
        width: 100%;
        height: 6px;
        background-color: #ecf0f1;
        border-radius: 3px;
        overflow: hidden;
        margin: 8px 0;
    }

    .evaluation-compact .bar-fill {
        height: 100%;
        background: linear-gradient(90deg, #e67e22, #d35400);
        border-radius: 3px;
        transition: width 0.3s ease;
    }

    .evaluation-compact .total {
        font-size: 13px;
        font-weight: 600;
        color: #2c3e50;
        margin-top: 5px;
    }

    .evaluation-compact .no-data {
        font-size: 14px;
        color: #7f8c8d;
        font-style: italic;
        padding: 15px 0;
        text-align: center;
    }

    /* Estilos para comentarios */
    .comment-block {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        border-left: 3px solid #e65f00;
    }

    .comment-block h4 {
        color: #2c3e50;
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .comment-block h4 i {
        color: #e65f00;
    }

    .comment-content {
        color: #34495e;
        font-size: 14px;
        line-height: 1.6;
        white-space: pre-line;
    }

    .comment-empty {
        color: #7f8c8d;
        font-style: italic;
        padding: 10px 0;
    }

    /* ===== WIDGETS UNIFICADOS (ESTILO SUGGESTIONS) ===== */
    .suggestions {
        margin-bottom: 20px;
    }

    .suggestions .sd-title {
        padding: 15px 15px 5px;
    }

    .suggestions .sd-title h3 {
        display: flex;
        align-items: center;
        gap: 8px;
        margin: 0;
        font-size: 16px;
    }

    .suggestions .sd-title h3 i {
        color: #e65f00 !important;
        font-size: 18px;
    }

    .suggestions .suggestions-list {
        padding: 0 15px 15px;
    }

    .suggestions .suggestion-usd {
        padding: 8px 0;
        color: #7f8c8d;
        font-size: 13px;
    }

    .suggestions .view-more {
        text-align: center;
        width: 100%;
    }

    .suggestions .view-more a {
        color: #e65f00;
        text-decoration: none;
        font-size: 12px;
        font-weight: 700;
    }

    .suggestions .view-more a:hover {
        text-decoration: underline;
    }
    
    /* ===== ESTILO PARA LISTADO DE EVALUACIONES ===== */
    .evaluation-item {
        display: flex;
        gap: 15px;
        padding: 15px 0;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .evaluation-item:last-child {
        border-bottom: none;
    }
    
    .evaluation-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        overflow: hidden;
        flex-shrink: 0;
    }
    
    .evaluation-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .evaluation-content {
        flex: 1;
    }
    
    .evaluation-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 5px;
        flex-wrap: wrap;
    }
    
    .evaluation-author {
        font-weight: 600;
        color: #2c3e50;
        font-size: 14px;
    }
    
    .evaluation-date {
        font-size: 12px;
        color: #95a5a6;
        display: flex;
        align-items: center;
        gap: 3px;
    }
    
    .evaluation-rating {
        font-size: 11px;
        font-weight: 600;
        padding: 2px 8px;
        border-radius: 12px;
        text-transform: uppercase;
    }
    
    .rating-positive {
        background-color: #e8f5e9;
        color: #27ae60;
        border: 1px solid #27ae60;
    }
    
    .rating-neutral {
        background-color: #f5f5f5;
        color: #7f8c8d;
        border: 1px solid #95a5a6;
    }
    
    .rating-negative {
        background-color: #fdeded;
        color: #e74c3c;
        border: 1px solid #e74c3c;
    }
    
    .rating-noanswer {
        background-color: #fef5e7;
        color: #f39c12;
        border: 1px solid #f39c12;
    }
    
    .evaluation-text {
        font-size: 13px;
        color: #34495e;
        line-height: 1.5;
        margin-top: 5px;
        word-break: break-word;
    }
    
    .evaluation-actions {
        margin-top: 8px;
    }
    
    .evaluation-actions .dropdown {
        position: relative;
        display: inline-block;
    }
    
    .evaluation-actions .dropdown-toggle {
        color: #95a5a6;
        cursor: pointer;
        font-size: 16px;
        padding: 0 5px;
    }
    
    .evaluation-actions .dropdown-menu {
        display: none;
        position: absolute;
        background-color: white;
        min-width: 150px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        border-radius: 6px;
        padding: 8px 0;
        z-index: 10;
        right: 0;
    }
    
    .evaluation-actions .dropdown-menu a {
        display: block;
        padding: 8px 15px;
        color: #2c3e50;
        font-size: 13px;
        text-decoration: none;
    }
    
    .evaluation-actions .dropdown-menu a:hover {
        background-color: #f8f9fa;
        color: #e65f00;
    }
    
    .evaluation-actions .dropdown:hover .dropdown-menu {
        display: block;
    }
    
    .evaluations-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 15px;
        padding: 0 15px;
    }
    
    .evaluations-header h3 {
        margin: 0;
        font-size: 18px;
        color: #2c3e50;
    }
    
    .evaluations-header a {
        color: #e65f00;
        text-decoration: none;
        font-size: 13px;
        font-weight: 500;
    }
    
    .evaluations-header a:hover {
        text-decoration: underline;
    }
</style>

<div class="main-section">
    <div class="container">
        <div class="main-section-data">
            <div class="row">
                <!-- SIDEBAR IZQUIERDO -->
                <div class="col-lg-3 col-md-4 pd-left-none no-pd">
                    <div class="main-left-sidebar no-margin">
                        <div class="user-data full-width">
                            <div class="user-profile">
                                <!-- ELIMINADO EL CÁLCULO DE ALTURA - AHORA LA FOTO ES FIJA -->
                                <div class="username-dt">
                                    <div class="usr-pic">
                                        <img src="<?php echo $foto_nombre; ?>?nocache=<?php echo time(); ?>">
                                    </div>
                                </div>

                                <div class="user-specs">
                                    <h3><?php echo $nombre_usuar; ?></h3>
                                    <span><i class="fas fa-id-card"></i> #<?php echo $identificador_usu_buscado; ?></span>

                                    <?php
                                    // UBICACIÓN Y DISTANCIA
                                    if (!($gpslat11 == 0 and $gpslng11 == 0)) {
                                        echo "<h6 style=\"font-size:110%; margin:8px 0;\"><i class=\"fas fa-map-marker-alt\"></i> " . $fila['Ciudad'] . " area</h6>";
                                    }

                                    if (!(($gpslat11 == 0 and $gpslng11 == 0) or ($mi_gpslat == 0 and $mi_gpslng == 0))) {
                                        echo "<h6 style=\"font-size:90%; margin:8px 0;\"><i class=\"fas fa-road\"></i> $distancia_entre_partners km away</h6>";
                                    }

                                    // ORGANIZACIÓN
                                    $domain1 = substr($email_del_usu, (int) strpos($email_del_usu, '@') + 1);
                                    $organization_id1 = $organization_id2 = null;

                                    $query123 = "
                                    SELECT organization_name AS org_name, org.organization_id AS org_id
                                    FROM organization_emails orgem 
                                    INNER JOIN organizations org ON org.organization_id = orgem.organization_id
                                    WHERE orgem.email_domain='$domain1'";
                                    $result123 = mysqli_query($link, $query123);
                                    if (mysqli_num_rows($result123)) {
                                        $fila123 = mysqli_fetch_array($result123);
                                        $organization1 = $fila123['org_name'];
                                        $organization_id1 = $fila123['org_id'];

                                        $domain2 = substr($mi_email, (int) strpos($mi_email, '@') + 1);
                                        $query990 = "
                                        SELECT organization_name AS org_name, org.organization_id AS org_id
                                        FROM organization_emails orgem 
                                        INNER JOIN organizations org ON org.organization_id = orgem.organization_id
                                        WHERE orgem.email_domain='$domain2'";
                                        $result990 = mysqli_query($link, $query990);
                                        if (mysqli_num_rows($result990)) {
                                            $fila990 = mysqli_fetch_array($result990);
                                            $organization2 = $fila990['org_name'];
                                            $organization_id2 = $fila990['org_id'];
                                        }
                                    }

                                    if ($organization_id2 == $organization_id1 && !empty($organization_id1)) {
                                        echo '<div style="margin:10px 0 5px;">';
                                        echo '<p style="color: #e65f00; display:flex; align-items:center; gap:5px;">';
                                        echo '<i class="fas fa-building"></i> ' . $organization1;
                                        echo '</p>';
                                        echo '</div>';
                                    }

                                    $id_contactante = $identificador2017;
                                    $identificador_contactado = $identificador_usu_buscado;

                                    // BOOKMARK CHECK
                                    $query642 = "SELECT * FROM bookmarkedusers WHERE userwhosaves='$id_contactante' AND userwhoissaved='$identificador_contactado'";
                                    $result642 = mysqli_query($link, $query642);
                                    $nuevos642 = mysqli_num_rows($result642);

                                    if (!$nuevos642) {
                                        echo '<div style="margin:15px 0 10px;">';
                                        echo '<a class="btn btn-primary btn-lg launch-modal" data-url="../bookmarks/addbookmark.php?idfav=' . $identificador_contactado . '"><i class="fas fa-bookmark"></i> Add to bookmarks</a>';
                                        echo '</div>';
                                    ?>
                                        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                                        <script>
                                            $(".launch-modal").on("click", function() {
                                                var url = $(this).data("url");
                                                $.ajax({
                                                    url: url,
                                                    method: "GET",
                                                    success: function(response) {
                                                        var popup = $("<div></div>")
                                                            .text("The bookmark has been added successfully!")
                                                            .css({
                                                                "position": "fixed",
                                                                "top": "50%",
                                                                "left": "50%",
                                                                "transform": "translate(-50%, -50%)",
                                                                "background-color": "green",
                                                                "color": "white",
                                                                "padding": "15px",
                                                                "border-radius": "5px",
                                                                "box-shadow": "0px 0px 10px rgba(0, 0, 0, 0.2)",
                                                                "font-size": "14px",
                                                                "z-index": "1000"
                                                            })
                                                            .hide();

                                                        $("body").append(popup);
                                                        popup.fadeIn(300).delay(2000).fadeOut(300);

                                                        setTimeout(function() {
                                                            location.reload();
                                                        }, 3300);
                                                    },
                                                    error: function(xhr, status, error) {
                                                        alert("There was an error adding the bookmark.");
                                                    }
                                                });
                                            });
                                        </script>
                                    <?php
                                    }

                                    // COUPLES CHECK
                                    $query1 = "SELECT * FROM couples2009antiguos WHERE (user_id_1='$id_contactante' AND user_id_2='$identificador_contactado') OR (user_id_2='$id_contactante' AND user_id_1='$identificador_contactado')";
                                    $result1 = mysqli_query($link, $query1);

                                    if (mysqli_num_rows($result1)) {
                                        echo '<div style="margin:15px 0 10px;">';
                                        echo '<form action="../trackerproposals/sent-studentcreateproposal.php">';
                                        echo '<input type="text" id="tid" name="tid" value="' . $identificador_contactado . '" hidden>';
                                        echo '<button class="btn btn-primary btn-lg" type="submit"><i class="fas fa-calendar-check"></i> Request a meeting</button>';
                                        echo '</form>';
                                        echo '</div>';
                                    } else {
                                        echo '<div style="margin:15px 0 10px;">';
                                        echo '<button class="btn btn-primary btn-lg launch-modal" data-toggle="modal" data-target="#myModal"><i class="fas fa-envelope"></i> Write a message</button>';
                                        echo '</div>';
                                    }
                                    ?>

                                    <!-- MODAL FORMULARIO -->
                                    <form name="mensaje_usu" ENCTYPE="multipart/form-data" ACTION="<?php echo './sndmsg.php?id_receptor=' . $id_del_receptor; ?>" METHOD="POST" id="formMensaje">
                                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                        <h4 class="modal-title" id="myModalLabel">Friendship request and Direct message to user</h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <textarea rows="5" cols="20" wrap="soft" name="mensajedelusuario" maxlength="255" id="textareaID" class="form-control" placeholder="Write your message here..." oninput="checkInput()"></textarea>
                                                        <p id="charCount">0/255</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        <input type="submit" name="enviar" id="sendMessageBtn" class="btn btn-primary" style="background-color: rgb(141, 119, 103); border: none; color: white; padding: 7px 10px; text-align: center;" value="Send message" disabled />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- SUGGESTIONS IZQUIERDO - Title 3 -->
                        <div class="suggestions full-width">
                            <div class="sd-title">
                                <h3><i class="fas fa-lightbulb"></i> Title 3</h3>
                            </div>
                            <div class="suggestions-list">
                                <div class="suggestion-usd">Placeholder 3</div>
                                <div class="view-more"><a href="./partners.php">Link 3</a></div>
                            </div>
                        </div>

                        <!-- SUGGESTIONS IZQUIERDO - Title 4 -->
                        <div class="suggestions full-width">
                            <div class="sd-title">
                                <h3><i class="fas fa-lightbulb"></i> Title 4</h3>
                            </div>
                            <div class="suggestions-list">
                                <div class="suggestion-usd">Placeholder 4</div>
                                <div class="view-more"><a href="./partners.php">Link 4</a></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- COLUMNA CENTRAL -->
                <div class="col-lg-6 col-md-7 no-pd">
                    <div class="posts-section">
                        <div id="seccion_teach" class="post-bar">
                            <div class="epi-sec"></div>

                            <!-- SECCIÓN: I know these languages -->
                            <div class="job_descp">
                                <h3 style="font-size:18px; margin:5px 0 15px 0;"><i class="fas fa-graduation-cap"></i> I know these languages</h3>
                                <ul class="skill-tags">
                                    <?php for ($iii = 0; $iii < count($my_langs_array); $iii++) {
                                        $idof = $my_langs_array[$iii];
                                        $idof_2letras = strtolower($my_langs_2letters_array[$iii]);
                                        $level_idiomaofre = $my_langs_level_array[$iii];
                                        $tooltip_ofr = $my_langs_typeofexchange_array[$iii];
                                        $full_name = $my_langs_full_name_array[$iii];
                                    ?>
                                        <li>
                                            <?php
                                            $bandera_path = "./images/banderasseparadas2024/{$idof_2letras}.png";
                                            if (!file_exists($bandera_path)) {
                                                $bandera_path = "./images/placeholder.png";
                                            }
                                            ?>
                                            <img src="<?php echo $bandera_path; ?>" alt="<?php echo htmlspecialchars($idof, ENT_QUOTES); ?> flag">

                                            <?php echo renderLevelDots($level_idiomaofre); ?>

                                            <div>
                                                <strong><?php echo strtoupper($idof); ?></strong><br>
                                                <span style="color:#7f8c8d;"><?php echo $idiomas_nivel["$level_idiomaofre"]; ?></span>
                                            </div>

                                            <?php if (!empty($my_langs_priceorexchangetext_array[$iii])): ?>
                                                <div class="<?php echo ($my_langs_price_array[$iii] == null) ? 'lang-exchange' : 'lang-price'; ?>">
                                                    <?php echo $my_langs_priceorexchangetext_array[$iii]; ?>
                                                </div>
                                            <?php endif; ?>

                                            <div class="tooltip-container">
                                                <i class="fas fa-info-circle"></i>
                                                <span class="tooltip-text">
                                                    <strong><?php echo htmlspecialchars($full_name, ENT_QUOTES); ?></strong><br>
                                                    <?php echo htmlspecialchars($tooltip_ofr, ENT_QUOTES); ?>
                                                </span>
                                            </div>
                                        </li>
                                    <?php } ?>
                                </ul>
                            </div>

                            <div class="epi-sec" style="margin:20px 0;"></div>

                            <!-- SECCIÓN: I want to learn these languages -->
                            <div class="job_descp">
                                <h3 style="font-size:18px; margin:5px 0 15px 0;"><i class="fas fa-book-open"></i> I want to learn these languages</h3>
                                <ul class="skill-tags">
                                    <?php for ($iii = 0; $iii < count($learn_langs_array); $iii++) {
                                        $idof = $learn_langs_array[$iii];
                                        $idof_2letras = strtolower($learn_langs_2letters_array[$iii]);
                                        $level_idiomaofre = $learn_langs_level_array[$iii];
                                        $full_name = $learn_langs_full_name_array[$iii];
                                    ?>
                                        <li>
                                            <?php
                                            $bandera_path = "./images/banderasseparadas2024/{$idof_2letras}.png";
                                            if (!file_exists($bandera_path)) {
                                                $bandera_path = "./images/placeholder.png";
                                            }
                                            ?>
                                            <img src="<?php echo $bandera_path; ?>" alt="<?php echo htmlspecialchars($idof, ENT_QUOTES); ?> flag">

                                            <?php echo renderLevelDots($level_idiomaofre); ?>

                                            <div>
                                                <strong><?php echo strtoupper($idof); ?></strong><br>
                                                <span style="color:#7f8c8d;"><?php echo $idiomas_nivel["$level_idiomaofre"]; ?></span>
                                            </div>

                                            <div class="tooltip-container">
                                                <i class="fas fa-info-circle"></i>
                                                <span class="tooltip-text">
                                                    <strong><?php echo htmlspecialchars($full_name, ENT_QUOTES); ?></strong>
                                                </span>
                                            </div>
                                        </li>
                                    <?php } ?>
                                </ul>
                            </div>

                            <div class="epi-sec"></div>

                            <!-- SECCIÓN: More information -->
                            <div class="job_descp">
                                <h3 style="font-size:18px; margin:5px 0 15px 0;"><i class="fas fa-info-circle"></i> More information</h3>
                                <?php if (!empty($availability100)): ?>
                                    <div style="margin-bottom:10px; font-size:14px;"><i class="fas fa-clock"></i> <?php echo nl2br(htmlspecialchars($availability100, ENT_QUOTES)); ?></div>
                                <?php endif; ?>
                                <?php if (!empty($othercomments100)): ?>
                                    <div style="margin-bottom:10px; font-size:14px;"><i class="fas fa-comment"></i> <?php echo nl2br(htmlspecialchars($othercomments100, ENT_QUOTES)); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- ===== SECCIÓN DE EVALUACIONES CON BARRA DE PROGRESO ===== -->
                    <div class="suggestions full-width" style="margin-top:20px;">
                        <div class="sd-title">
                            <h3><i class="fas fa-star"></i> Evaluations</h3>
                        </div>
                        
                        <?php
                        // Consulta para obtener evaluaciones con LEFT JOIN
                        $query1010 = "
                            SELECT m.nombre AS nombre1, m.orden AS orden1, m.fotoext AS fotoext1, 
                                   comentarios.comment, comentarios.hora, comentarios.rating
                            FROM comentarios
                            LEFT JOIN mentor2009 AS m ON m.orden = comentarios.id_autor
                            WHERE comentarios.id_aludido='$identificador_usu_buscado' AND comentarios.censurado=0 
                            ORDER BY comentarios.horacreacion DESC
                            LIMIT 3
                        ";
                        $result1010 = mysqli_query($link, $query1010);
                        $num_evaluaciones = mysqli_num_rows($result1010);
                        ?>
                        
                        <div class="suggestions-list">
                            <?php if ($evaluation_data['has_evaluations']): ?>
                                
                                <!-- BARRA DE PROGRESO NARANJA (usando evaluation_data) -->
                                <div class="evaluation-compact" style="margin-bottom:20px; padding-bottom:15px; border-bottom:1px solid #ecf0f1;">
                                    <div class="metric">
                                        <i class="fas fa-star"></i>
                                        <span class="percentage"><?php echo $evaluation_data['percentage']; ?><small>%</small></span>
                                    </div>
                                    <div class="bar">
                                        <div class="bar-fill" style="width: <?php echo $evaluation_data['percentage']; ?>%;"></div>
                                    </div>
                                    <div class="total">
                                        Based on <?php echo $evaluation_data['total']; ?> review<?php echo $evaluation_data['total'] > 1 ? 's' : ''; ?>
                                    </div>
                                </div>
                                
                                <!-- LISTADO DE COMENTARIOS -->
                                <?php while ($fila1010 = mysqli_fetch_array($result1010)): 
                                    $comentario_ev = $fila1010['comment'];
                                    $hora_ev = $fila1010['hora'];
                                    $rating_ev = $fila1010['rating'];
                                    
                                    // Determinar clase de rating según el valor
                                    if ($rating_ev == 1) {
                                        $rating_text = "POSITIVE";
                                        $rating_class = "rating-positive";
                                    } elseif ($rating_ev == 2) {
                                        $rating_text = "NEUTRAL";
                                        $rating_class = "rating-neutral";
                                    } elseif ($rating_ev == 3) {
                                        $rating_text = "NEGATIVE";
                                        $rating_class = "rating-negative";
                                    } elseif ($rating_ev == 4) {
                                        $rating_text = "NO ANSWER";
                                        $rating_class = "rating-noanswer";
                                    } else {
                                        $rating_text = $rating_ev;
                                        $rating_class = "rating-neutral";
                                    }
                                    
                                    $autor_ev = $fila1010['nombre1'];
                                    
                                    // php8: a explode no se le puede meter nada con null
                                    if (!is_null($autor_ev)) {
                                        $palabras = explode(" ", $autor_ev);
                                        $autor_ev = ucfirst($palabras[0]);
                                    }
                                    
                                    if ($autor_ev == '') {
                                        $autor_ev = "User unregistered";
                                    }
                                    
                                    $foto_extension = $fila1010['fotoext1'];
                                    $orden47 = $fila1010['orden1'];
                                    
                                    // Obtener foto del autor usando detectarFoto
                                    $foto_autor = $orden47 ? detectarFoto($orden47, 'thumb') : "../uploader/default.jpg";
                                ?>
                                    <div class="evaluation-item">
                                        <div class="evaluation-avatar">
                                            <img src="<?php echo $foto_autor; ?>" alt="<?php echo htmlspecialchars($autor_ev); ?>">
                                        </div>
                                        <div class="evaluation-content">
                                            <div class="evaluation-header">
                                                <span class="evaluation-author"><?php echo $autor_ev; ?></span>
                                                <span class="evaluation-date"><i class="far fa-calendar-alt"></i> <?php echo date("Y-m-d", strtotime($hora_ev)); ?></span>
                                                <span class="evaluation-rating <?php echo $rating_class; ?>"><?php echo $rating_text; ?></span>
                                            </div>
                                            <div class="evaluation-text">
                                                <?php echo nl2br(htmlspecialchars($comentario_ev)); ?>
                                            </div>
                                            <div class="evaluation-actions">
                                                <div class="dropdown">
                                                    <span class="dropdown-toggle">⋯</span>
                                                    <div class="dropdown-menu">
                                                        <?php if ($orden47): ?>
                                                            <a href="./u.php?identificador=<?php echo $orden47; ?>">Visit profile</a>
                                                        <?php endif; ?>
                                                        <a href="./reportabuse.php">Report abuse</a>
                                                        <a href="./resolutioncenter.php">Resolution center</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                                
                                <?php if ($evaluation_data['total'] > 3): ?>
                                    <div class="view-more" style="margin-top:15px;">
                                        <a href="../infouser/evdonepartners.php?u=<?php echo $identificador_usu_buscado; ?>">View older evaluations</a>
                                    </div>
                                <?php endif; ?>
                                
                            <?php else: ?>
                                <div class="suggestion-usd" style="text-align:center; padding:20px 0;">
                                    <i class="fas fa-star" style="font-size:24px; opacity:0.3; margin-bottom:10px;"></i>
                                    <p>No evaluations yet</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- SIDEBAR DERECHO - CON ESTILO SUGGESTIONS -->
                <div class="col-lg-3 pd-right-none no-pd">
                    <div class="right-sidebar">
                        
                        <!-- SUGGESTIONS DERECHO - Title 1 -->
                        <div class="suggestions full-width">
                            <div class="sd-title">
                                <h3><i class="fas fa-lightbulb"></i> Title 1</h3>
                            </div>
                            <div class="suggestions-list">
                                <div class="suggestion-usd">Placeholder 1</div>
                                <div class="view-more"><a href="./partners.php">Link 1</a></div>
                            </div>
                        </div>

                        <!-- SUGGESTIONS DERECHO - Title 2 -->
                        <div class="suggestions full-width">
                            <div class="sd-title">
                                <h3><i class="fas fa-lightbulb"></i> Title 2</h3>
                            </div>
                            <div class="suggestions-list">
                                <div class="suggestion-usd">Placeholder 2</div>
                                <div class="view-more"><a href="./partners.php">Link 2</a></div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" type="text/css" href="../files/modalbox1/css_modalboxtextarea/bootstrap.min.css">

<script>
    $(document).ready(function() {
        var column1 = $('#seccion_teach').clone().attr('id', 'seccion_teach_clone');
        $('#column1').append(column1);
        var column2 = $('#events').clone().attr('id', 'events_clone');
        $('#column2').append(column2);
        var column3 = $('#my_events').clone().attr('id', 'my_events_clone');
        $('#column3').append(column3);

        resize_movil();
        window.addEventListener("resize", function() {
            resize_movil();
        });
    });

    function resize_movil() {
        $("#seccion_teach_clone").css("margin-bottom", "0px");
        $("#events_clone").css("margin-bottom", "0px");

        if (screen.width < 768) {
            $("#seccion_teach").attr("hidden", true);
            $("#seccion_teach_clone").attr("hidden", false);
            $("#events").attr("hidden", true);
            $("#events_clone").attr("hidden", false);
            $("#my_events").attr("hidden", true);
            $("#my_events_clone").attr("hidden", false);
        } else {
            $("#seccion_teach").attr("hidden", false);
            $("#seccion_teach_clone").attr("hidden", true);
            $("#events").attr("hidden", false);
            $("#events_clone").attr("hidden", true);
            $("#my_events").attr("hidden", false);
            $("#my_events_clone").attr("hidden", true);
        }
    }

    function checkInput() {
        var mensaje = document.getElementById("textareaID");
        var sendMessageBtn = document.getElementById("sendMessageBtn");
        var charCount = document.getElementById("charCount");

        var mensajeLength = mensaje.value.length;

        if (mensajeLength > 255) {
            mensaje.value = mensaje.value.substring(0, 255);
            mensajeLength = 255;
        }

        charCount.textContent = mensajeLength + "/255";

        if (mensaje.value.trim() !== "") {
            sendMessageBtn.disabled = false;
            sendMessageBtn.style.backgroundColor = "#e65f00";
        } else {
            sendMessageBtn.disabled = true;
            sendMessageBtn.style.backgroundColor = "rgb(141, 119, 103)";
        }
    }

    document.getElementById("textareaID").addEventListener("input", checkInput);

    document.getElementById("formMensaje").addEventListener("submit", function(event) {
        var mensaje = document.getElementById("textareaID").value.trim();
        console.log("Mensaje capturado: " + mensaje);
    });
</script>

<?php
require('../templates/footer.php');
?>